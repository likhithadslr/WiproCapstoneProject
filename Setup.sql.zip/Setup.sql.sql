create database mydb;

use mydb;

go

CREATE TABLE Users (
Id INT IDENTITY(1,1) PRIMARY KEY,
Username NVARCHAR(50) NOT NULL,
Email NVARCHAR(100) NOT NULL,
Password VARBINARY(MAX) NOT NULL,
FirstName NVARCHAR(50) NULL,
LastName NVARCHAR(50) NULL,
Weight INT NULL,
Height INT NULL,
DateOfBirth DATETIME NULL,
Gender NVARCHAR(20) NULL,
CreatedAt DATETIME NOT NULL DEFAULT GETUTCDATE(),
UpdatedAt DATETIME NULL
);


CREATE UNIQUE INDEX IX_Users_Username ON Users(Username);
CREATE UNIQUE INDEX IX_Users_Email ON Users(Email);


CREATE TABLE Workouts (
Id INT IDENTITY(1,1) PRIMARY KEY,
UserId INT NOT NULL,
Type NVARCHAR(50) NOT NULL,
Name NVARCHAR(100) NOT NULL,
Duration INT NOT NULL,
Calories INT NULL,
Date DATETIME NOT NULL,
Notes NVARCHAR(500) NULL,
CreatedAt DATETIME NOT NULL DEFAULT GETUTCDATE(),
UpdatedAt DATETIME NULL,
CONSTRAINT FK_Workouts_Users FOREIGN KEY (UserId) REFERENCES Users(Id) ON DELETE CASCADE
);  

select * from Workouts;

CREATE INDEX IX_Workouts_UserId ON Workouts(UserId);
CREATE INDEX IX_Workouts_Date ON Workouts(Date);   

CREATE TABLE CalorieEntries (
Id INT IDENTITY(1,1) PRIMARY KEY,
UserId INT NOT NULL,
FoodName NVARCHAR(100) NOT NULL,
Calories INT NOT NULL,
MealType NVARCHAR(50) NOT NULL,
Date DATETIME NOT NULL,
Notes NVARCHAR(200) NULL,
CreatedAt DATETIME NOT NULL DEFAULT GETUTCDATE(),
CONSTRAINT FK_CalorieEntries_Users FOREIGN KEY (UserId) REFERENCES Users(Id) ON DELETE CASCADE
);  

select * from CalorieEntries;

CREATE INDEX IX_CalorieEntries_UserId ON CalorieEntries(UserId);
CREATE INDEX IX_CalorieEntries_Date ON CalorieEntries(Date); 

insert into Users (Id,Username, Email, Password, FirstName, Weight, Height, DateOfBirth, Gender, CreatedAt, UpdatedAt) 
VALUES
(1,'Lik','lik@gmail.com','lik2305','ak',55,5,NULL,'F',GETUTCDATE(),GETUTCDATE()),
(2,'Aksh','ak@gmail.com','ak2305','br',65,6,NULL,'M',GETUTCDATE(),GETUTCDATE());


ALTER TABLE Users
ALTER COLUMN Password VARCHAR(100);

SET IDENTITY_INSERT Users ON;


select * from Workouts;

select * from CalorieEntries;

select * from Users;


