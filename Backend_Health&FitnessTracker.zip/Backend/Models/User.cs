﻿
using System.ComponentModel.DataAnnotations;
using System;
using Backend.Models;

namespace Backend.Models
{
    public class User
    {
        [Key]
        public Guid Id { get; set; }
        [Required]
        public string Username { get; set; }
        [Required]
        [EmailAddress]
        public string Email { get; set; }
        //[Required]
        public string PasswordHash { get; set; } // Store the hashed password

        // Navigation property for Workouts
        public ICollection<Workout> Workouts { get; set; }

        // Navigation property for CaloriesEntries
        public ICollection<CaloriesEntry> CaloriesEntries { get; set; }
    }

}