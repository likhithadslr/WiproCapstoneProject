﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace Backend.Models
{
    public class CaloriesEntry
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "The FoodName field is required.")]
        public string FoodName { get; set; }

        [Required(ErrorMessage = "The Date field is required.")]
        public DateTime Date { get; set; }

        [Required(ErrorMessage = "The Calories field is required.")]
        public int Calories { get; set; }

        public int WaterIntake { get; set; }

        [Required(ErrorMessage = "The UserId field is required.")]
        [JsonPropertyName("userId")] // Maps incoming 'userId' field in JSON to 'UserId' property
        public Guid UserId { get; set; }

        //[JsonIgnore] // Prevent EF Core navigation property from being included in API requests
        //public User User { get; set; }
    }
}
