﻿
using System.ComponentModel.DataAnnotations;
using System;
using Backend.Models;

namespace Backend.Models
{
    public class Workout
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string ExerciseName { get; set; }
        public DateTime Date { get; set; }
        public int Time { get; set; } // in minutes
        public int CaloriesBurned { get; set; }

        // Foreign key for User
        public Guid UserId { get; set; }

        // Navigation property for User
        public User User { get; set; }
    }
}