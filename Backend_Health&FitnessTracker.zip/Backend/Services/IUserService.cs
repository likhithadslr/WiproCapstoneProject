﻿
using Backend.Models;
using System.Threading.Tasks;

namespace Backend.Services
{
    public interface IUserService
    {
        Task<User> GetUserByEmail(string email);
        Task<bool> RegisterUser(RegisterModel model);
        Task<string> GenerateJwtToken(User user);
    }
}