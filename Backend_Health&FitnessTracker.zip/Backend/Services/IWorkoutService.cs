﻿
using Backend.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Backend.Services
{
    public interface IWorkoutService
    {
        Task<List<Workout>> GetWorkouts(Guid userId);
        Task<Workout> GetWorkout(int id, Guid userId);
        Task<Workout> CreateWorkout(Workout workout, Guid userId);

    }
}