﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Backend.Data;
using Backend.Models;
using Backend.Services;

namespace Backend.Services
{
    public class WorkoutService : IWorkoutService
    {
        private readonly AppDbContext _context;

        public WorkoutService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<List<Workout>> GetWorkouts(Guid userId)
        {
            return await Task.FromResult(_context.Workouts.Where(w => w.UserId == userId).ToList());
        }

        public async Task<Workout> GetWorkout(int id, Guid userId)
        {
            var workoutTask = _context.Workouts.FindAsync(id);
            var workout = await workoutTask; // Await the task to get the Workout object

            if (workout == null || workout.UserId != userId)
            {
                return null;
            }

            return workout;
        }

        public async Task<Workout> CreateWorkout(Workout workout, Guid userId)
        {
            workout.UserId = userId;
            _context.Workouts.Add(workout);
            await _context.SaveChangesAsync();
            return workout;
        }
    }
}
