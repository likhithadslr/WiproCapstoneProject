﻿// Controllers/AuthController.cs
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.AspNetCore.Authorization;
using System;
using System.Linq;
using Microsoft.AspNetCore.Identity;
using System.Threading.Tasks;
using Backend.Data;
using Backend.Models;
using Backend.Services;

namespace Backend.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly IUserService _userService;
        private readonly IConfiguration _configuration;
        private readonly AppDbContext _context; // Add this line

        public AuthController(IUserService userService, IConfiguration configuration, AppDbContext context)  //Add AppDbContext
        {
            _userService = userService;
            _configuration = configuration;
            _context = context; // Add this line to initialize the context
        }

        [HttpPost("Register")]
        public async Task<IActionResult> Register(RegisterModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (!await _userService.RegisterUser(model))
            {
                return BadRequest("Email already in use.");
            }

            return Ok(new { Message = "User registered successfully" });
        }

        [HttpPost("Login")]
        public async Task<IActionResult> Login(LoginModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var user = await _userService.GetUserByEmail(model.Email);

            if (user == null)
            {
                return Unauthorized("Invalid username or password.");
            }

            var passwordHasher = new PasswordHasher<User>();
            var result = passwordHasher.VerifyHashedPassword(user, user.PasswordHash, model.Password);

            if (result == PasswordVerificationResult.Failed)
            {
                return Unauthorized("Invalid username or password.");
            }

            // Generate JWT token
            var token = _userService.GenerateJwtToken(user);

            return Ok(new { Token = token, Message = "Login successful" });
        }
        [Authorize]
        [HttpGet("Me")]
        public IActionResult Me()
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier); // Get user ID from claims
            var user = _context.Users.Find(userId); //Now it is accessible
            if (user == null)
            {
                return NotFound();
            }

            return Ok(new { user.Email, user.Username });
        }

    }
}