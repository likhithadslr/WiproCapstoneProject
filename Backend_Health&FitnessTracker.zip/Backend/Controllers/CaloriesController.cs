﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Backend.Data;
using Backend.Models;
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;

namespace Backend.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    //[Authorize] // Require authentication
    public class CaloriesController : ControllerBase
    {
        private readonly AppDbContext _context;

        public CaloriesController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet("Calories")]
        public IActionResult GetCaloriesEntries()
        {
            // Get the user ID from the claims
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);

            // Fetch only the calories entries belonging to the current user
            var caloriesEntries = _context.CaloriesEntries.Where(c => c.UserId.ToString() == userId).ToList();

            return Ok(caloriesEntries);
        }

        [HttpPost("Calories")]
        public IActionResult CreateCaloriesEntry([FromBody] CaloriesEntry caloriesEntry)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            // Get the user ID from the claims
            //var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);

            // Set the UserId of the workout
            //caloriesEntry.UserId = Guid.Parse(caloriesEntry.);

            _context.CaloriesEntries.Add(caloriesEntry);
            _context.SaveChanges();

            return CreatedAtAction(nameof(GetCaloriesEntry), new { id = caloriesEntry.Id }, caloriesEntry);
        }

        [HttpGet("{id}")]
        public IActionResult GetCaloriesEntry(int id)
        {
            var caloriesEntry = _context.CaloriesEntries.Find(id);

            if (caloriesEntry == null)
            {
                return NotFound();
            }
            // Get the user ID from the claims
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);

            // Check if the caloriesEntry belongs to the current user
            if (caloriesEntry.UserId.ToString() != userId)
            {
                return Unauthorized();
            }

            return Ok(caloriesEntry);
        }
    }
}