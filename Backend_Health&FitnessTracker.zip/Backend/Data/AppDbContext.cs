﻿using Microsoft.EntityFrameworkCore;
using System;
using Backend.Models;

namespace Backend.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }

        public DbSet<User> Users { get; set; }
        public DbSet<Workout> Workouts { get; set; }
        public DbSet<CaloriesEntry> CaloriesEntries { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Configure relationships
            modelBuilder.Entity<Workout>()
                .HasOne(w => w.User)
                .WithMany(u => u.Workouts)
                .HasForeignKey(w => w.UserId);

            modelBuilder.Entity<CaloriesEntry>()
                //.HasOne(c => c.User)
                //.WithMany(u => u.CaloriesEntries)
                //.HasForeignKey(c => c.UserId)
                ;

            // Map CaloriesEntry to the correct table name
            modelBuilder.Entity<CaloriesEntry>()
                .ToTable("CaloriesEntries");

            // Seed initial data (optional)
            modelBuilder.Entity<User>().HasData(new User
            {
                Id = Guid.Parse("123e4567-e89b-12d3-a456-426614174000"),
                Email = "a@gmail.com",
                Username = "a",
                PasswordHash = "1234"
            });
        }
    }
}