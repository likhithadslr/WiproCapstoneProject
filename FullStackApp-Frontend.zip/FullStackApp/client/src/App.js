import React, { useEffect, useState } from 'react';
import { Routes, Route } from 'react-router-dom';
import HomePage from './pages/HomePage';
import WorkoutPage from './pages/WorkoutPage';
import CaloriesPage from './pages/CaloriesPage';
import TrendsPage from './pages/TrendsPage';
import AuthPage from './pages/AuthPage';
import './App.css';
import { isAuthenticated } from './utils/auth';
import Navbar from './components/NavBar';
//import LoginPage from './pages/loginPage';



const App = () => {
    const [isAuth, setIsAuth] = useState(isAuthenticated());

    // ✅ Listen for auth changes
    useEffect(() => {
        const handleAuthChange = () => setIsAuth(isAuthenticated());

        window.addEventListener('authChange', handleAuthChange);
        return () => window.removeEventListener('authChange', handleAuthChange);
    }, []);

    return (
        <div>
            <Navbar />
            <Routes>
                {isAuth ? (
                    <>
                        <Route path="/" element={<AuthPage />} />
                        <Route path="home" element={<HomePage />} />
                        <Route path="workout" element={<WorkoutPage />} />
                        <Route path="calories" element={<CaloriesPage />} />
                        <Route path="trends" element={<TrendsPage />} />
                        
                    </>
                ) : (
                    <Route path="*" element={<AuthPage />} />
                )}
            </Routes>
        </div>
    );
};

export default App; 

