// Dummy user data (for demo purposes only)
// const users = [
//     { email: "a@gmail.com", password: "1234" }
// ];

export const isAuthenticated = () => {
    return localStorage.getItem("isAuthenticated") === "true";
};

// export const registerUser = (email, password) => {
//     const userExists = users.some(user => user.email == email);

//     if (userExists) {
//         return { success: false, message: "User already exists. Please log in." };
//     }

//     users.push({ email, password });
//     localStorage.setItem("isAuthenticated", "true");
//     return { success: true, message: "Registration successful! Redirecting..." };
// };

// export const loginUser = (email, password) => {
//     const validUser = users.some(user => user.email === email && user.password === password);

//     if (validUser) {
//         localStorage.setItem("isAuthenticated", "true");
//         return { success: true, message: "Login successful! Redirecting..." };
//     }

//     return { success: false, message: "Invalid email or password. Please try again." };
// };


export const logoutUser = () => {
    localStorage.removeItem("isAuthenticated");

    window.dispatchEvent(new Event("authChange"));
};
