import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { isAuthenticated, logoutUser } from '../utils/auth';

const Navbar = () => {
    const isAuth = isAuthenticated();
    const navigate = useNavigate();

    const handleLogout = () => {
        logoutUser();  // ✅ Clear token and notify app
        navigate('/auth');  // ✅ Redirect immediately
    };

    return (
        <nav className="bg-gradient-to-r from-blue-500 to-purple-600 text-white shadow-md">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex items-center justify-between h-16">
                    <div className="flex-shrink-0 text-2xl font-bold">
                        <NavLink to="/" className="hover:text-yellow-300 transition duration-300">
                            FitTrack
                        </NavLink>
                    </div>

                    <div className="hidden md:flex space-x-6">
                        <NavLink to="/home" className="hover:text-yellow-300">Home</NavLink>

                        {isAuth && (
                            <>
                                <NavLink to="/workout" className="hover:text-yellow-300">Log Workout</NavLink>
                                <NavLink to="/calories" className="hover:text-yellow-300">Track Calories</NavLink>
                                <NavLink to="/trends" className="hover:text-yellow-300">View Trends</NavLink>

                                {/* ✅ Logout Button */}
                                <button 
                                    onClick={handleLogout}
                                    className="bg-red-500 px-4 py-2 rounded hover:bg-red-600 transition"
                                >
                                    Logout
                                </button>
                            </>
                        )}

                        {!isAuth && (
                            <NavLink to="/auth" className="hover:text-yellow-300">
                                Login / Register
                            </NavLink>
                        )}
                    </div>

                    {/* Mobile Menu (Optional for smaller screens) */}
                    <div className="md:hidden">
                        <button className="text-white focus:outline-none">☰</button>
                    </div>
                </div>
            </div>
        </nav>
    );
};

export default Navbar;
