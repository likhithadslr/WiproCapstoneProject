import React from 'react';
import { FaFire, FaRunning, FaTint, FaWeight } from 'react-icons/fa';
import {
    BarChart,
    Bar,
    LineChart,
    Line,
    XAxis,
    YAxis,
    Tooltip,
    CartesianGrid,
    ResponsiveContainer,
    Legend
} from 'recharts';

// Sample Data for Trends
const data = [
    { date: 'Mar 1', calories: 500, workoutTime: 45, waterIntake: 2000, weight: 70 },
    { date: 'Mar 2', calories: 600, workoutTime: 50, waterIntake: 2100, weight: 69.8 },
    { date: 'Mar 3', calories: 450, workoutTime: 30, waterIntake: 1800, weight: 69.5 },
    { date: 'Mar 4', calories: 700, workoutTime: 60, waterIntake: 2200, weight: 69.2 },
    { date: 'Mar 5', calories: 400, workoutTime: 25, waterIntake: 1700, weight: 69 },
];

const TrendsPage = () => (
    <div className="min-h-screen p-6 bg-gradient-to-br from-blue-50 to-blue-100">
        <h1 className="text-4xl font-extrabold text-center text-blue-600 mb-8">
            📊 Fitness Trends Dashboard
        </h1>

        {/* Key Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-10">

            {/* Calories Burned */}
            <div className="bg-white p-4 rounded-lg shadow-md text-center border-t-4 border-red-500">
                <FaFire className="text-red-500 text-3xl mx-auto mb-2" />
                <h3 className="text-xl font-bold">🔥 Calories Burned</h3>
                <p className="text-gray-600 text-lg">Avg: 530 kcal/day</p>
            </div>

            {/* Workout Time */}
            <div className="bg-white p-4 rounded-lg shadow-md text-center border-t-4 border-green-500">
                <FaRunning className="text-green-500 text-3xl mx-auto mb-2" />
                <h3 className="text-xl font-bold">⏱️ Workout Time</h3>
                <p className="text-gray-600 text-lg">Avg: 42 mins/day</p>
            </div>

            {/* Water Intake */}
            <div className="bg-white p-4 rounded-lg shadow-md text-center border-t-4 border-blue-400">
                <FaTint className="text-blue-400 text-3xl mx-auto mb-2" />
                <h3 className="text-xl font-bold">💧 Water Intake</h3>
                <p className="text-gray-600 text-lg">Avg: 2L/day</p>
            </div>

            {/* Weight Progress */}
            <div className="bg-white p-4 rounded-lg shadow-md text-center border-t-4 border-yellow-500">
                <FaWeight className="text-yellow-500 text-3xl mx-auto mb-2" />
                <h3 className="text-xl font-bold">⚖️ Weight</h3>
                <p className="text-gray-600 text-lg">Current: 69 kg</p>
            </div>
        </div>

        {/* Chart Section */}
        <div className="bg-white p-6 rounded-lg shadow-lg">
            <h2 className="text-2xl font-bold text-blue-600 mb-4">📈 Progress Over Time</h2>

            {/* Combined Chart */}
            <ResponsiveContainer width="100%" height={300}>
                <LineChart data={data}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Legend />

                    <Line type="monotone" dataKey="calories" stroke="#f87171" name="Calories Burned" />
                    <Line type="monotone" dataKey="workoutTime" stroke="#4ade80" name="Workout Time (mins)" />
                    <Line type="monotone" dataKey="waterIntake" stroke="#60a5fa" name="Water Intake (ml)" />
                    <Line type="monotone" dataKey="weight" stroke="#facc15" name="Weight (kg)" />
                </LineChart>
            </ResponsiveContainer>

            {/* Bar Chart for Calories */}
            <div className="mt-8">
                <h2 className="text-2xl font-bold text-blue-600 mb-4">🔥 Weekly Calorie Burn</h2>
                <ResponsiveContainer width="100%" height={250}>
                    <BarChart data={data}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="date" />
                        <YAxis />
                        <Tooltip />
                        <Bar dataKey="calories" fill="#f87171" name="Calories Burned" />
                    </BarChart>
                </ResponsiveContainer>
            </div>
        </div>
    </div>
);

export default TrendsPage;
