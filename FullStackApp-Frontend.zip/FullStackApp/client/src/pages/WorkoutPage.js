import React, { useState } from 'react';
import { FaDumbbell, FaCalendarAlt, FaClock, FaFire } from 'react-icons/fa';

const WorkoutPage = () => {
    const [exerciseName, setExerciseName] = useState('');
    const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
    const [time, setTime] = useState('');
    const [caloriesBurned, setCaloriesBurned] = useState('');
    const [workouts, setWorkouts] = useState({});

    const handleWorkoutSubmit = () => {
        console.log('Handling Workout Submit');
        
        if (!exerciseName || !time || !caloriesBurned) {
            alert("Please fill all fields");
            return;
        }

        const newEntry = {
            exerciseName,
            time: parseInt(time),
            calories: parseInt(caloriesBurned),
        };

        setWorkouts((prevWorkouts) => {
            const updatedWorkouts = { ...prevWorkouts };
            if (!updatedWorkouts[date]) {
                updatedWorkouts[date] = [];
            }
            updatedWorkouts[date].push(newEntry);
            return updatedWorkouts;
        });

        setExerciseName('');
        setTime('');
        setCaloriesBurned('');
    };

    return (
        <div className="min-h-screen p-6 bg-gradient-to-br from-blue-50 to-blue-100">
            <h1 className="text-4xl font-extrabold text-center text-blue-600 mb-8">
                💪 Log Your Workout
            </h1>

            {/* Horizontal Input Fields */}
            <div className="bg-white p-6 rounded-lg shadow-lg max-w-4xl mx-auto flex flex-wrap items-center gap-4">

                {/* Exercise Name */}
                <div className="flex items-center gap-2 border rounded p-2 flex-grow">
                    <FaDumbbell className="text-blue-500" />
                    <input
                        type="text"
                        placeholder="Exercise Name"
                        value={exerciseName}
                        onChange={(e) => setExerciseName(e.target.value)}
                        className="w-full outline-none"
                    />
                </div>

                {/* Date */}
                <div className="flex items-center gap-2 border rounded p-2">
                    <FaCalendarAlt className="text-blue-500" />
                    <input
                        type="date"
                        value={date}
                        onChange={(e) => setDate(e.target.value)}
                        className="w-full outline-none"
                    />
                </div>

                {/* Time (mins) */}
                <div className="flex items-center gap-2 border rounded p-2">
                    <FaClock className="text-yellow-500" />
                    <input
                        type="number"
                        placeholder="Time (mins)"
                        value={time}
                        onChange={(e) => setTime(e.target.value)}
                        className="w-full outline-none"
                    />
                </div>

                {/* Calories Burned */}
                <div className="flex items-center gap-2 border rounded p-2">
                    <FaFire className="text-red-500" />
                    <input
                        type="number"
                        placeholder="Calories Burned"
                        value={caloriesBurned}
                        onChange={(e) => setCaloriesBurned(e.target.value)}
                        className="w-full outline-none"
                    />
                </div>

                {/* Submit Button - Centered */}
                <div className="w-full text-center mt-4">
                    <button
                        onClick={handleWorkoutSubmit}
                        className="bg-blue-500 text-white py-2 px-6 rounded hover:bg-blue-600 transition duration-300"
                    >
                        ➕ Add Workout
                    </button>
                </div>
            </div>

            {/* Display Workouts */}
            <div className="mt-10 space-y-6">
                {Object.keys(workouts).map((date) => (
                    <div
                        key={date}
                        className="bg-white p-4 rounded-lg shadow-md border-l-8 border-blue-500"
                    >
                        <h2 className="text-xl font-bold text-blue-700">{date}</h2>
                        <ul className="list-disc pl-5 mt-2">
                            {workouts[date].map((entry, index) => (
                                <li key={index} className="text-gray-700">
                                    {entry.exerciseName} - {entry.time} mins - {entry.calories} calories burned
                                </li>
                            ))}
                        </ul>

                        {/* Total Time & Calories Burned */}
                        <div className="flex justify-between font-semibold mt-3">
                            <div className="text-green-600">
                                Total Time: {workouts[date].reduce((sum, entry) => sum + entry.time, 0)} mins
                            </div>
                            <div className="text-red-500">
                                Total Calories Burned: {workouts[date].reduce((sum, entry) => sum + entry.calories, 0)}
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default WorkoutPage;
