import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const AuthPage = () => {
    const [isRegister, setIsRegister] = useState(true);
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [message, setMessage] = useState('');
    const navigate = useNavigate();


    const handleSubmit = async (e) => {
        e.preventDefault();

        // Construct API request based on login / register
        const requestBody = {
            // grant_type: isRegister ? 'register' : 'password',
            email: email,
            password: password,
            confirmPassword: password
            // ...(isRegister ? { username: email.split('@')[0] } : {}),

        };

        try {
            
            if(isRegister){
                console.log('isRegister ' + isRegister);
                const response = await fetch('https://localhost:7056/api/Auth/Register', {  // Replace with your API endpoint
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(requestBody),
                });

                const result = await response.json();

                setMessage(result.message);
                console.log('Response '+ result.success)
                if (result.success) {
                    localStorage.setItem('token', result.token);
                    navigate('/');
                }
                else{

                }
            }
            else{
                console.log('isRegister ' + isRegister);
                const reqBody = {
                    email: email,
                    password: password
                  };

                  console.log('reqbody ' + JSON.stringify(reqBody))
            
                  const response = await fetch('https://localhost:7056/api/Auth/Login', {  
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(reqBody),
                  });
            
                  const result = await response.json();

                  setMessage(result.message);
                //   console.log('Response ' + JSON().parse(result));
                //   result = JSON().parse(result);
                  // setMessage(result.message);
            
                  if (result.token) {
                    console.log(result);
                    localStorage.setItem('token', result.token);
                    localStorage.setItem("isAuthenticated", "true");
                    window.dispatchEvent(new Event('authChange'));
                    navigate('/home');
                    // console.log('Login successful', { email, rememberMe });
                  } else {
                    console.log('Login Fail');
                      // setMessage(result.message);  // Display error message from the backend
                  }
            }
        } catch (error) {
            console.error('Authentication error:', error);
            setMessage('Authentication failed. Please try again.');
        }
    };

    return (
        <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-blue-100 p-6">
            <div className="bg-white p-8 rounded-lg shadow-lg max-w-md w-full">
                <h2 className="text-3xl font-bold text-blue-600 text-center mb-6">
                    {isRegister ? 'Create an Account' : 'Welcome Back'}
                </h2>

                <form onSubmit={handleSubmit} className="space-y-4">
                    <input
                        type="email"
                        placeholder="Email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                        className="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
                    />

                    <input
                        type="password"
                        placeholder="Password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                        className="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
                    />

                    <button
                        type="submit"
                        // onClick={handleNavigate}
                        className="w-full bg-blue-500 text-white py-2 rounded-lg hover:bg-blue-600 transition duration-300"
                    >
                        {isRegister ? 'Register' : 'Login'}
                    </button>
                </form>

                <p className="text-center text-gray-500 mt-4">
                    {isRegister
                        ? "Already have an account? "
                        : "Don't have an account? "}
                    <span
                        className="text-blue-500 cursor-pointer underline"
                        onClick={() => setIsRegister(!isRegister)}
                        // onClick={handleNavigate}
                    >
                        {isRegister ? 'Login' : 'Register'}
                    </span>
                </p>

                {message && (
                    <p
                        className={`text-center mt-4 font-semibold ${
                            message.includes('success') ? 'text-green-500' : 'text-red-500'
                        }`}
                    >
                        {message}
                    </p>
                )}
            </div>
        </div>
    );
};

export default AuthPage;