import React, { useState } from 'react';
import { FaUtensils, FaCalendarAlt, FaBurn, FaTint } from 'react-icons/fa';

const CaloriesPage = () => {
    const [foodName, setFoodName] = useState('');
    const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
    const [calories, setCalories] = useState('');
    const [waterIntake, setWaterIntake] = useState('');
    const [entries, setEntries] = useState({});

    // Handle calorie submission
    const handleCalorieSubmit = async (e) => {
        e.preventDefault();
    
        if (!foodName || !date || !calories) {
            alert("Please fill all fields");
            return;
        }
    
        const reqBody = {
            foodName,
            waterIntake,
            date,
            calories
        };
    
        try {
            // const response = await fetch('https://localhost:7056/api/Calories', {
            //     method: 'POST',
            //     headers: {
            //         'Content-Type': 'application/json',
            //     },
            //     body: JSON.stringify(reqBody),
            // });
    
            // const result = await response.json();
            // alert(result.message || 'Entry added successfully!');
    
            setEntries((prevEntries) => {
                const updatedEntries = { ...prevEntries };
                if (!updatedEntries[date]) {
                    updatedEntries[date] = [];
                }
                updatedEntries[date].push({
                    foodName,
                    calories: parseInt(calories),
                    water: parseInt(waterIntake) || 0
                });
    
                return updatedEntries;
            });
    
            // Clear inputs
            setFoodName('');
            setCalories('');
            setWaterIntake('');
    
        } catch (error) {
            console.error('Error submitting entry:', error);
            alert('Failed to submit entry. Please try again.');
        }
    };
    

    return (
        <div className="min-h-screen p-6 bg-gradient-to-br from-blue-50 to-blue-100">
            <h1 className="text-4xl font-extrabold text-center text-blue-600 mb-8">
                🥗 Track Your Calories
            </h1>

            {/* Input Fields */}
            <div className="bg-white p-6 rounded-lg shadow-lg max-w-md mx-auto">
                {/* Food Name Input */}
                <div className="flex items-center gap-2 mb-3 border rounded p-2">
                    <FaUtensils className="text-blue-500" />
                    <input
                        type="text"
                        placeholder="Food Name"
                        value={foodName}
                        onChange={(e) => setFoodName(e.target.value)}
                        className="w-full outline-none"
                    />
                </div>

                {/* Date Input */}
                <div className="flex items-center gap-2 mb-3 border rounded p-2">
                    <FaCalendarAlt className="text-blue-500" />
                    <input
                        type="date"
                        value={date}
                        onChange={(e) => setDate(e.target.value)}
                        className="w-full outline-none"
                    />
                </div>

                {/* Calories Intake Input */}
                <div className="flex items-center gap-2 mb-3 border rounded p-2">
                    <FaBurn className="text-red-500" />
                    <input
                        type="number"
                        placeholder="Calories Intake"
                        value={calories}
                        onChange={(e) => setCalories(e.target.value)}
                        className="w-full outline-none"
                    />
                </div>

                {/* Water Intake Input */}
                <div className="flex items-center gap-2 mb-3 border rounded p-2">
                    <FaTint className="text-blue-400" />
                    <input
                        type="number"
                        placeholder="Water Intake (ml)"
                        value={waterIntake}
                        onChange={(e) => setWaterIntake(e.target.value)}
                        className="w-full outline-none"
                    />
                </div>

                {/* Submit Button */}
                <button
                    onClick={handleCalorieSubmit}
                    className="w-full bg-blue-500 text-white py-2 rounded hover:bg-blue-600 transition duration-300"
                >
                    ➕ Add Entry
                </button>
            </div>

            {/* Display Entries */}
            <div className="mt-10 space-y-6">
                {Object.keys(entries).map((date) => (
                    <div
                        key={date}
                        className="bg-white p-4 rounded-lg shadow-md border-l-8 border-blue-500"
                    >
                        <h2 className="text-xl font-bold text-blue-700">{date}</h2>
                        <ul className="list-disc pl-5 mt-2">
                            {entries[date].map((entry, index) => (
                                <li key={index} className="text-gray-700">
                                    {entry.foodName} - {entry.calories} calories, {entry.water}ml water
                                </li>
                            ))}
                        </ul>

                        {/* Total Calories & Water */}
                        <div className="flex justify-between font-semibold mt-3">
                            <div className="text-green-600">
                                Total Calories: {entries[date].reduce((sum, entry) => sum + entry.calories, 0)}
                            </div>
                            <div className="text-blue-500">
                                Total Water: {entries[date].reduce((sum, entry) => sum + entry.water, 0)} ml
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default CaloriesPage;
