import React from 'react';
import { FaDumbbell, FaUtensils, FaBed } from 'react-icons/fa';
import { Line } from 'react-chartjs-2';

import { Chart as ChartJS, LineElement, CategoryScale, LinearScale, PointElement } from 'chart.js';

ChartJS.register(LineElement, CategoryScale, LinearScale, PointElement);

const Dashboard = () => {
    const data = {
        labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4'],
        datasets: [
            {
                label: 'Exercise',
                data: [30, 60, 40, 80],
                borderColor: '#00bfff',
                backgroundColor: 'rgba(0, 191, 255, 0.2)',
                fill: true,
            },
            {
                label: 'Meals',
                data: [50, 40, 70, 60],
                borderColor: '#ff6347',
                backgroundColor: 'rgba(255, 99, 71, 0.2)',
                fill: true,
            }
        ]
    };

    return (
        <div className="min-h-screen bg-gray-100 p-6 flex">
            {/* Sidebar */}
            <div className="w-1/4 bg-white p-4 rounded-2xl shadow-md">
                <h1 className="text-2xl font-bold text-gray-800 mb-6">TRACK <span className="text-blue-500">FITNESS</span></h1>
                <div className="mb-4">
                    <p className="font-semibold">Richard Jones</p>
                    <p className="text-sm text-gray-500">Male, 28 years</p>
                </div>
                <div className="space-y-4">
                    <div className="flex justify-between">
                        <span>Height</span>
                        <span>185 cm</span>
                    </div>
                    <div className="flex justify-between">
                        <span>Weight</span>
                        <span>176 kg</span>
                    </div>
                </div>
            </div>

            {/* Main Dashboard */}
            <div className="w-3/4 ml-6">
                <div className="grid grid-cols-3 gap-4 mb-6">
                    <div className="bg-blue-400 text-white p-4 rounded-2xl">
                        <FaDumbbell className="text-3xl mb-2" />
                        <h3>10 Exercises</h3>
                        <p>1 hour 50 minutes</p>
                    </div>
                    <div className="bg-red-400 text-white p-4 rounded-2xl">
                        <FaUtensils className="text-3xl mb-2" />
                        <h3>6 Meals</h3>
                        <p>1604.0 cal</p>
                    </div>
                    <div className="bg-green-400 text-white p-4 rounded-2xl">
                        <FaBed className="text-3xl mb-2" />
                        <h3>8 Hours Sleep</h3>
                    </div>
                </div>
                <div className="bg-white p-6 rounded-2xl shadow-md">
                    <h3 className="text-lg font-bold mb-4">Statistics - Last Month</h3>
                    <Line data={data} />
                </div>
            </div>
        </div>
    );
};

export default Dashboard;



// import React, { useEffect } from 'react';
// import { useDispatch, useSelector } from 'react-redux';
// import { fetchWorkouts } from '../store/actions/workoutActions';
// import { fetchMeals } from '../store/actions/nutritionActions';
// import { selectUser } from '../store/selectors/authSelectors';
// import { selectRecentWorkouts } from '../store/selectors/workoutSelectors';
// import { selectTodaysMeals, selectTotalCaloriesForDay } from '../store/selectors/nutritionSelectors';
// import DailySummary from '../components/dashboard/DailySummary';
// import ActivityRing from '../components/dashboard/ActivityRing';
// import GoalProgress from '../components/dashboard/GoalProgress';
// import RecentWorkouts from '../components/dashboard/RecentWorkouts';
// import NutritionSummary from '../components/nutrition/NutritionSummary';
// import Card from '../components/common/Card';
// import Loader from '../components/common/Loader';
// import './Dashboard.css';

// const Dashboard = () => {
//   const dispatch = useDispatch();
//   const user = useSelector(selectUser);
//   const recentWorkouts = useSelector(state => selectRecentWorkouts(state, 3));
//   const todaysMeals = useSelector(selectTodaysMeals);
//   const todaysCalories = useSelector(state => 
//     selectTotalCaloriesForDay(state, new Date())
//   );
  
//   const workoutLoading = useSelector(state => state.workout.loading);
//   const nutritionLoading = useSelector(state => state.nutrition.loading);
  
//   useEffect(() => {
//     dispatch(fetchWorkouts());
//     dispatch(fetchMeals());
//   }, [dispatch]);
  
//   if (workoutLoading || nutritionLoading) {
//     return <Loader fullScreen text="Loading your fitness data..." />;
//   }
  
//   return (
//     <div className="dashboard">
//       <header className="dashboard-header">
//         <h1>Welcome back, {user?.name || 'Fitness Enthusiast'}!</h1>
//         <p className="dashboard-date">{new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
//       </header>
      
//       <div className="dashboard-summary">
//         <DailySummary 
//           caloriesConsumed={todaysCalories}
//           calorieGoal={user?.dailyCalorieGoal || 2000} 
//           workoutsCompleted={recentWorkouts.length}
//           streakDays={user?.streakDays || 0}
//         />
//       </div>
      
//       <div className="dashboard-grid">
//         <div className="dashboard-activity">
//           <Card title="Today's Activity" className="activity-card">
//             <div className="activity-rings">
//               <ActivityRing 
//                 title="Calories"
//                 current={todaysCalories}
//                 max={user?.dailyCalorieGoal || 2000}
//                 color="#FF5B5B"
//               />
//               <ActivityRing 
//                 title="Exercise"
//                 current={recentWorkouts.reduce((sum, w) => sum + w.duration, 0)}
//                 max={user?.dailyExerciseGoal || 60}
//                 color="#5B8CFF"
//                 unit="min"
//               />
//               <ActivityRing 
//                 title="Steps"
//                 current={user?.todaySteps || 0}
//                 max={user?.dailyStepGoal || 10000}
//                 color="#5BFF9F"
//               />
//             </div>
//           </Card>
//         </div>
        
//         <div className="dashboard-goals">
//           <Card title="Goals Progress" className="goals-card">
//             <GoalProgress 
//               goals={[
//                 { 
//                   title: 'Weekly Workouts', 
//                   current: recentWorkouts.length, 
//                   target: user?.weeklyWorkoutGoal || 5,
//                   unit: 'workouts'
//                 },
//                 { 
//                   title: 'Weight Goal', 
//                   current: user?.currentWeight || 70, 
//                   target: user?.targetWeight || 65,
//                   unit: 'kg',
//                   reversed: user?.currentWeight > user?.targetWeight
//                 },
//                 { 
//                   title: 'Water Intake', 
//                   current: user?.todayWaterIntake || 0, 
//                   target: user?.dailyWaterGoal || 2000,
//                   unit: 'ml'
//                 }

// ]}
//             />
//           </Card>
//         </div>
        
//         <div className="dashboard-workouts">
//           <Card 
//             title="Recent Workouts" 
//             className="workouts-card"
//             footer={
//               <a href="/workouts" className="view-all-link">View all workouts</a>
//             }
//           >
//             <RecentWorkouts workouts={recentWorkouts} />
//           </Card>
//         </div>
        
//         <div className="dashboard-nutrition">
//           <Card 
//             title="Today's Nutrition" 
//             className="nutrition-card"
//             footer={
//               <a href="/nutrition" className="view-all-link">View all meals</a>
//             }
//           >
//             <NutritionSummary 
//               meals={todaysMeals}
//               totalCalories={todaysCalories}
//               calorieGoal={user?.dailyCalorieGoal || 2000}
//             />
//           </Card>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Dashboard;