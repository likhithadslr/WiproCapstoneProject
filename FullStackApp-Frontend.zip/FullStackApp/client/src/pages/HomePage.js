import React from 'react';
import { Link } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';

const HomePage = () => {
    const navigate = useNavigate();

    return (
    <div className="min-h-screen bg-gray-100 flex flex-col items-center justify-center p-6">
        <h1 className="text-4xl font-bold text-blue-600 mb-8">Health & Fitness Tracker</h1>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full max-w-5xl">
            {/* Workout Section */}
            <div className="bg-white shadow-md rounded-lg p-4">
                <img 
                    src="/images/workout.jpg" 
                    alt="Workout Session" 
                    className="rounded-t-lg w-full h-40 object-cover"
                />
                <div className="p-4">
                    <h2 className="text-xl font-semibold mb-2">Log Your Workout</h2>
                    <p className="text-gray-600 mb-4">
                        Keep track of your workout routines to achieve your fitness goals faster.
                    </p>
                    <Link 
                        to="/workout" 
                        className="inline-block bg-blue-500 text-white py-2 px-4 rounded-md hover:bg-blue-600"
                    >
                        Log Workout
                    </Link>
                </div>
            </div>

            {/* Calories Section */}
            <div className="bg-white shadow-md rounded-lg p-4">
                <img 
                    src="/images/calories.jpg" 
                    alt="Healthy Food" 
                    className="rounded-t-lg w-full h-40 object-cover"
                />
                <div className="p-4">
                    <h2 className="text-xl font-semibold mb-2">Track Your Calories</h2>
                    <p className="text-gray-600 mb-4">
                        Monitor your daily calorie intake to maintain a balanced diet.
                    </p>
                    <Link 
                        to="/calories" 
                        className="inline-block bg-green-500 text-white py-2 px-4 rounded-md hover:bg-green-600"
                    >
                        Track Calories
                    </Link>
                </div>
            </div>

            {/* Trends Section */}
            <div className="bg-white shadow-md rounded-lg p-4">
                <img 
                    src="/images/trends.jpg" 
                    alt="Fitness Trends Chart" 
                    className="rounded-t-lg w-full h-40 object-cover"
                />
                <div className="p-4">
                    <h2 className="text-xl font-semibold mb-2">View Fitness Trends</h2>
                    <p className="text-gray-600 mb-4">
                        Visualize your progress with insightful charts and analytics.
                    </p>
                    <Link 
                        to="/trends" 
                        className="inline-block bg-purple-500 text-white py-2 px-4 rounded-md hover:bg-purple-600"
                    >
                        View Trends
                    </Link>
                </div>
            </div>
        </div>
    </div>
    );
}

export default HomePage;
